<?php 

require_once("../controllers/main.php");

class UserController extends Controller {
    
    private $db;
    private $result;

    public function __construct() {
        parent::__construct();
        $this->db = $this->connection();
        require_once("../model/user_model.php");
    }

    public function getUserAll() {
        $this->result = null;
        try {
            $userModel = new UserModel($this->db);
            $this->result = $userModel->getAll();
        } catch (PDOException $e) {
            $this->result = false;
        }

        return $this->result;
    }

}