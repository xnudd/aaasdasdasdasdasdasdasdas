<?php

class Controller {

    private $db;

    public function __construct() {
        require_once("../vendor/autoload.php");
        $dotenv = Dotenv\Dotenv::createImmutable("../config");
        $dotenv->load();
        require_once("../config/database.php");
        $database = new Database($_ENV["HOST"], $_ENV["DATABASE_NAME"], $_ENV["DATABASE_USER"], $_ENV["DATABASE_PASS"], $_ENV["PORT"]);
        $this->db = $database->connection();
    }

    public function connection() {
        return $this->db;
    }

}