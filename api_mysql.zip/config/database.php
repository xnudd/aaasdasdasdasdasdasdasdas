<?php

class Database {

    private $host;
    private $db_name;
    private $db_username;
    private $db_password;
    private $port;

    public $conn;

    public function __construct($host, $db_name, $db_username, $db_password, $port) {
        $this->host = $host;
        $this->db_name = $db_name;
        $this->db_username = $db_username;
        $this->db_password = $db_password;
        $this->port = $port;
    }

    public function connection() {

        $this->conn = null;

        try {
            $this->conn = new PDO (
                "mysql:host=" . $this->host .";
                port=" . $this->port .";
                dbname=" . $this->db_name,
                $this->db_username,
                $this->db_password,
            );
        } catch (PDOException $e) {
            $this->conn = "ไม่สามารถเชื่อมต่อฐานข้อมูลได้" . $e->getMessage();
        }

        return $this->conn;
    }

}